#define SpinVersion	"Spin Version 5.1.4 -- 27 January 2008"
