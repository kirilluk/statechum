package attributes;

import domains.*;
import jedd.*;

public class dst extends Attribute {
    public final Var domain = (Var) Var.v();
    
    public Domain domain() { return domain; }
    
    public static Attribute v() { return instance; }
    
    private static Attribute instance = new dst();
    
    public dst() { super(); }
}
