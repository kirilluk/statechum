package attributes;

import domains.*;
import jedd.*;

public class fld extends Attribute {
    public final Field domain = (Field) Field.v();
    
    public Domain domain() { return domain; }
    
    public static Attribute v() { return instance; }
    
    private static Attribute instance = new fld();
    
    public fld() { super(); }
}
