package attributes;

import domains.*;
import jedd.*;

public class base extends Attribute {
    public final Var domain = (Var) Var.v();
    
    public Domain domain() { return domain; }
    
    public static Attribute v() { return instance; }
    
    private static Attribute instance = new base();
    
    public base() { super(); }
}
