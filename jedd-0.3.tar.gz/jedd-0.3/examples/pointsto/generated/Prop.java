import java.io.*;
import java.util.*;
import jedd.*;
import jedd.order.*;
import java.util.zip.*;
import attributes.*;
import domains.*;
import physical_domains.*;

public class Prop {
    final jedd.internal.RelationContainer edgeSet =
      new jedd.internal.RelationContainer(new Attribute[] { src.v(), dst.v() },
                                          new PhysicalDomain[] { V1.v(), V2.v() },
                                          ("<attributes.src:physical_domains.V1, attributes.dst:physical" +
                                           "_domains.V2> edgeSet at Prop.jedd:11,4-20"));
    
    final jedd.internal.RelationContainer allocs =
      new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                          new PhysicalDomain[] { V1.v(), H1.v() },
                                          ("<attributes.var:physical_domains.V1, attributes.obj:physical" +
                                           "_domains.H1> allocs at Prop.jedd:12,4-20"));
    
    final jedd.internal.RelationContainer pointsTo =
      new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                          new PhysicalDomain[] { V1.v(), H1.v() },
                                          ("<attributes.var:physical_domains.V1, attributes.obj:physical" +
                                           "_domains.H1> pointsTo at Prop.jedd:13,4-20"));
    
    final jedd.internal.RelationContainer loads =
      new jedd.internal.RelationContainer(new Attribute[] { src.v(), fld.v(), dst.v() },
                                          new PhysicalDomain[] { V1.v(), FD.v(), V2.v() },
                                          ("<attributes.src:physical_domains.V1, attributes.fld:physical" +
                                           "_domains.FD, attributes.dst:physical_domains.V2> loads at Pr" +
                                           "op.jedd:14,4-28"));
    
    final jedd.internal.RelationContainer stores =
      new jedd.internal.RelationContainer(new Attribute[] { src.v(), fld.v(), dst.v() },
                                          new PhysicalDomain[] { V1.v(), FD.v(), V2.v() },
                                          ("<attributes.src:physical_domains.V1, attributes.fld:physical" +
                                           "_domains.FD, attributes.dst:physical_domains.V2> stores at P" +
                                           "rop.jedd:15,4-28"));
    
    final jedd.internal.RelationContainer typeFilter =
      new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                          new PhysicalDomain[] { V1.v(), H1.v() },
                                          ("<attributes.var, attributes.obj> typeFilter = jedd.internal." +
                                           "Jedd.v().trueBDD() at Prop.jedd:16,4-14"),
                                          jedd.internal.Jedd.v().trueBDD());
    
    final jedd.internal.RelationContainer solution =
      new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                          new PhysicalDomain[] { V1.v(), H1.v() },
                                          ("<attributes.var, attributes.obj> solution at Prop.jedd:17,4-" + "14"));
    
    final jedd.internal.RelationContainer varTypes =
      new jedd.internal.RelationContainer(new Attribute[] { var.v(), dtp.v() },
                                          new PhysicalDomain[] { V1.v(), V2.v() },
                                          ("<attributes.var, attributes.dtp> varTypes at Prop.jedd:18,4-" + "14"));
    
    final jedd.internal.RelationContainer objTypes =
      new jedd.internal.RelationContainer(new Attribute[] { obj.v(), atp.v() },
                                          new PhysicalDomain[] { H1.v(), V1.v() },
                                          ("<attributes.obj, attributes.atp> objTypes at Prop.jedd:19,4-" + "14"));
    
    final jedd.internal.RelationContainer subType =
      new jedd.internal.RelationContainer(new Attribute[] { dtp.v(), atp.v() },
                                          new PhysicalDomain[] { V2.v(), V1.v() },
                                          ("<attributes.dtp:physical_domains.V2, attributes.atp:physical" +
                                           "_domains.V1> subType at Prop.jedd:20,4-20"));
    
    private static Long getInt(StringTokenizer st) {
        Long ret = Long.decode(st.nextToken());
        return ret;
    }
    
    public static final void main(String[] args) throws Exception {
        Jedd.v().setBackend(args[0]);
        try {
            Jedd.v().enableProfiling(new PrintStream(new GZIPOutputStream(new FileOutputStream(new File("profile.sql.gz")))));
        }
        catch (IOException e) { throw new RuntimeException("couldn\'t write profile: " + e); }
        new Prop().main();
        Jedd.v().outputProfile();
    }
    
    public final void main() throws Exception {
        Jedd.v().setOrder(new Seq(FD.v(), V1.v(), V2.v(), H1.v(), H2.v()));
        parseInput();
        Jedd.v().gbc();
        System.out.println("starting propagation");
        propagate();
    }
    
    private void parseInput() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line;
        String mode = null;
        while (true) {
            line = br.readLine();
            if (line == null) break;
            if (line.indexOf(":") >= 0) {
                mode = line;
                System.out.println("reading " + mode);
                continue;
            }
            StringTokenizer st = new StringTokenizer(line);
            if (mode.indexOf("Allocations") >= 0) {
                Object o1 = getInt(st);
                Object o2 = getInt(st);
                allocs.eq(jedd.internal.Jedd.v().union(jedd.internal.Jedd.v().read(allocs),
                                                       jedd.internal.Jedd.v().literal(new Object[] { o1, o2 },
                                                                                      new Attribute[] { obj.v(), var.v() },
                                                                                      new PhysicalDomain[] { H1.v(), V1.v() })));
            } else
                if (mode.indexOf("Assignments") >= 0) {
                    edgeSet.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st) },
                                                                   new Attribute[] { src.v(), dst.v() },
                                                                   new PhysicalDomain[] { V1.v(), V2.v() }));
                } else
                    if (mode.indexOf("Loads") >= 0) {
                        loads.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st), getInt(st) },
                                                                     new Attribute[] { src.v(), fld.v(), dst.v() },
                                                                     new PhysicalDomain[] { V1.v(), FD.v(), V2.v() }));
                    } else
                        if (mode.indexOf("Stores") >= 0) {
                            stores.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st), getInt(st) },
                                                                          new Attribute[] { src.v(), dst.v(), fld.v() },
                                                                          new PhysicalDomain[] { V1.v(), V2.v(), FD.v() }));
                        } else
                            if (mode.indexOf("Solution") >= 0) {
                                solution.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st) },
                                                                                new Attribute[] { var.v(), obj.v() },
                                                                                new PhysicalDomain[] { V1.v(), H1.v() }));
                            } else
                                if (mode.indexOf("Declared Types") >= 0) {
                                    subType.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st) },
                                                                                   new Attribute[] { dtp.v(), atp.v() },
                                                                                   new PhysicalDomain[] { V2.v(), V1.v() }));
                                } else
                                    if (mode.indexOf("Allocation Types") >= 0) {
                                        objTypes.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st) },
                                                                                        new Attribute[] { obj.v(), atp.v() },
                                                                                        new PhysicalDomain[] { H1.v(), V1.v() }));
                                    } else
                                        if (mode.indexOf("Variable Types") >= 0) {
                                            varTypes.eqUnion(jedd.internal.Jedd.v().literal(new Object[] { getInt(st), getInt(st) },
                                                                                            new Attribute[] { var.v(), dtp.v() },
                                                                                            new PhysicalDomain[] { V1.v(), V2.v() }));
                                        }
        }
        if (!jedd.internal.Jedd.v().equals(jedd.internal.Jedd.v().read(subType), jedd.internal.Jedd.v().falseBDD())) {
            typeFilter.eq(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(subType),
                                                                                                                    objTypes,
                                                                                                                    new PhysicalDomain[] { V1.v() })),
                                                         varTypes,
                                                         new PhysicalDomain[] { V2.v() }));
        }
        varTypes.eq(jedd.internal.Jedd.v().falseBDD());
        objTypes.eq(jedd.internal.Jedd.v().falseBDD());
        subType.eq(jedd.internal.Jedd.v().falseBDD());
        System.out.println("Nodes in points-to BDD: " +
                           new jedd.internal.RelationContainer(new Attribute[] { obj.v(), var.v() },
                                                               new PhysicalDomain[] { H1.v(), V1.v() },
                                                               "pointsTo.numNodes() at Prop.jedd:90,55-63",
                                                               pointsTo).numNodes());
        System.out.println("Nodes in loads BDD: " +
                           new jedd.internal.RelationContainer(new Attribute[] { fld.v(), src.v(), dst.v() },
                                                               new PhysicalDomain[] { FD.v(), V1.v(), V2.v() },
                                                               "loads.numNodes() at Prop.jedd:91,51-56",
                                                               loads).numNodes());
        System.out.println("Nodes in stores BDD: " +
                           new jedd.internal.RelationContainer(new Attribute[] { fld.v(), src.v(), dst.v() },
                                                               new PhysicalDomain[] { FD.v(), V1.v(), V2.v() },
                                                               "stores.numNodes() at Prop.jedd:92,52-58",
                                                               stores).numNodes());
        System.out.println("Nodes in edge-set BDD: " +
                           new jedd.internal.RelationContainer(new Attribute[] { src.v(), dst.v() },
                                                               new PhysicalDomain[] { V1.v(), V2.v() },
                                                               "edgeSet.numNodes() at Prop.jedd:93,54-61",
                                                               edgeSet).numNodes());
    }
    
    private void propagate() {
        final jedd.internal.RelationContainer oldPt1 =
          new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                              new PhysicalDomain[] { V1.v(), H1.v() },
                                              ("<attributes.var:physical_domains.V1, attributes.obj:physical" +
                                               "_domains.H1> oldPt1; at Prop.jedd:99,19-25"));
        final jedd.internal.RelationContainer oldPt2 =
          new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                              new PhysicalDomain[] { V1.v(), H1.v() },
                                              ("<attributes.var:physical_domains.V1, attributes.obj:physical" +
                                               "_domains.H1> oldPt2; at Prop.jedd:100,19-25"));
        final jedd.internal.RelationContainer newPt =
          new jedd.internal.RelationContainer(new Attribute[] { var.v(), obj.v() },
                                              new PhysicalDomain[] { V1.v(), H1.v() },
                                              ("<attributes.var:physical_domains.V1, attributes.obj:physical" +
                                               "_domains.H1> newPt; at Prop.jedd:101,25-30"));
        final jedd.internal.RelationContainer objectsBeingStored =
          new jedd.internal.RelationContainer(new Attribute[] { obj.v(), var.v(), fld.v() },
                                              new PhysicalDomain[] { H1.v(), V2.v(), FD.v() },
                                              ("<attributes.obj:physical_domains.H1, attributes.var:physical" +
                                               "_domains.V2, attributes.fld:physical_domains.FD> objectsBein" +
                                               "gStored; at Prop.jedd:102,33-51"));
        final jedd.internal.RelationContainer fieldPt =
          new jedd.internal.RelationContainer(new Attribute[] { base.v(), fld.v(), obj.v() },
                                              new PhysicalDomain[] { H1.v(), FD.v(), H2.v() },
                                              ("<attributes.base:physical_domains.H1, attributes.fld:physica" +
                                               "l_domains.FD, attributes.obj:physical_domains.H2> fieldPt; a" +
                                               "t Prop.jedd:103,28-35"));
        final jedd.internal.RelationContainer loadsFromHeap =
          new jedd.internal.RelationContainer(new Attribute[] { base.v(), fld.v(), dst_var.v() },
                                              new PhysicalDomain[] { H1.v(), FD.v(), V2.v() },
                                              ("<attributes.base:physical_domains.H1, attributes.fld:physica" +
                                               "l_domains.FD, attributes.dst_var:physical_domains.V2> loadsF" +
                                               "romHeap; at Prop.jedd:104,38-51"));
        Date start = new Date();
        pointsTo.eq(allocs);
        allocs.eq(jedd.internal.Jedd.v().falseBDD());
        do  {
            oldPt1.eq(pointsTo);
            System.out.println("Starting outer iteration.");
            do  {
                oldPt2.eq(pointsTo);
                newPt.eq(jedd.internal.Jedd.v().replace(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(edgeSet),
                                                                                       pointsTo,
                                                                                       new PhysicalDomain[] { V1.v() }),
                                                        new PhysicalDomain[] { V2.v() },
                                                        new PhysicalDomain[] { V1.v() }));
                newPt.eq(jedd.internal.Jedd.v().intersect(jedd.internal.Jedd.v().read(newPt), typeFilter));
                pointsTo.eq(jedd.internal.Jedd.v().union(jedd.internal.Jedd.v().read(pointsTo), newPt));
            }while(!jedd.internal.Jedd.v().equals(jedd.internal.Jedd.v().read(oldPt2), pointsTo)); 
            newPt.eq(jedd.internal.Jedd.v().falseBDD());
            objectsBeingStored.eq(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(stores),
                                                                 pointsTo,
                                                                 new PhysicalDomain[] { V1.v() }));
            fieldPt.eq(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(jedd.internal.Jedd.v().replace(objectsBeingStored,
                                                                                                                 new PhysicalDomain[] { H1.v() },
                                                                                                                 new PhysicalDomain[] { H2.v() })),
                                                      jedd.internal.Jedd.v().replace(pointsTo,
                                                                                     new PhysicalDomain[] { V1.v() },
                                                                                     new PhysicalDomain[] { V2.v() }),
                                                      new PhysicalDomain[] { V2.v() }));
            objectsBeingStored.eq(jedd.internal.Jedd.v().falseBDD());
            loadsFromHeap.eq(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(loads),
                                                            pointsTo,
                                                            new PhysicalDomain[] { V1.v() }));
            newPt.eq(jedd.internal.Jedd.v().replace(jedd.internal.Jedd.v().compose(jedd.internal.Jedd.v().read(jedd.internal.Jedd.v().replace(loadsFromHeap,
                                                                                                                                              new PhysicalDomain[] { V2.v() },
                                                                                                                                              new PhysicalDomain[] { V1.v() })),
                                                                                   fieldPt,
                                                                                   new PhysicalDomain[] { H1.v(), FD.v() }),
                                                    new PhysicalDomain[] { H2.v() },
                                                    new PhysicalDomain[] { H1.v() }));
            loadsFromHeap.eq(jedd.internal.Jedd.v().falseBDD());
            newPt.eqIntersect(typeFilter);
            pointsTo.eqUnion(newPt);
        }while(!jedd.internal.Jedd.v().equals(jedd.internal.Jedd.v().read(oldPt1), pointsTo)); 
        if (jedd.internal.Jedd.v().equals(jedd.internal.Jedd.v().read(pointsTo), solution))
            System.out.println("solution matches");
        else
            System.out.println("solution doesn\'t match");
        System.out.println("Nodes in points-to BDD: " +
                           new jedd.internal.RelationContainer(new Attribute[] { obj.v(), var.v() },
                                                               new PhysicalDomain[] { H1.v(), V1.v() },
                                                               "pointsTo.numNodes() at Prop.jedd:157,55-63",
                                                               pointsTo).numNodes());
        System.out.println("Nodes in solution BDD: " +
                           new jedd.internal.RelationContainer(new Attribute[] { obj.v(), var.v() },
                                                               new PhysicalDomain[] { H1.v(), V1.v() },
                                                               "solution.numNodes() at Prop.jedd:158,54-62",
                                                               solution).numNodes());
        Jedd.v().gbc();
    }
    
    public Prop() { super(); }
}
