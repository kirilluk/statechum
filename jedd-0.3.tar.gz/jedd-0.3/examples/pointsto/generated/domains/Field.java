package domains;

import jedd.*;

public class Field extends Domain {
    public Numberer numberer() { return IntegerNumberer.v(); }
    
    private final int bits = 20;
    
    public int maxBits() { return bits; }
    
    public static Domain v() { return instance; }
    
    private static Domain instance = new Field();
    
    public Field() { super(); }
}
