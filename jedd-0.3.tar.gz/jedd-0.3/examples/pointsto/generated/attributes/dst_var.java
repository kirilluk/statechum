package attributes;

import domains.*;
import jedd.*;

public class dst_var extends Attribute {
    public final Var domain = (Var) Var.v();
    
    public Domain domain() { return domain; }
    
    public static Attribute v() { return instance; }
    
    private static Attribute instance = new dst_var();
    
    public dst_var() { super(); }
}
