package attributes;

import domains.*;
import jedd.*;

public class obj extends Attribute {
    public final Obj domain = (Obj) Obj.v();
    
    public Domain domain() { return domain; }
    
    public static Attribute v() { return instance; }
    
    private static Attribute instance = new obj();
    
    public obj() { super(); }
}
